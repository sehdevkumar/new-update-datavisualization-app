from django.apps import AppConfig


class AdmincontrolConfig(AppConfig):
    name = 'Admincontrol'
