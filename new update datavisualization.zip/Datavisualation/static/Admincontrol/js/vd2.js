$(document).ready(function(){


	const counter12 = document.querySelectorAll(".counter12");
	const counter22 = document.querySelectorAll(".counter22");
	const counter32 = document.querySelectorAll(".counter32");
	const counter42 = document.querySelectorAll(".counter42");
	
	var holdID2 = [];
	var holdTITLE2 = [];
	var holdDES2 = [];
	var holdFIGURE2 = [];

	var c12=0;
	var c22=0;
	var c32=0;
	var c42=0;



	counter12.forEach((item)=>{

		holdID2[c12++]=item.value;

	});
	counter22.forEach((item)=>{

		holdTITLE2[c22++]=item.value;

	});
	counter32.forEach((item)=>{

		holdDES2[c32++]=item.value;

	});
	counter42.forEach((item)=>{

		holdFIGURE2[c42++]=item.value;

	});

	// console.log(holdID);
	// console.log(holdTITLE);
	// console.log(holdDES);
	// console.log(holdFIGURE);
	$("#show_dashboard_title2").html(holdTITLE2[0]);
	$("#show_dashboard_des2").html(holdDES2[0]);
	$("#show_dashboard_figure2").html(holdFIGURE2[0]);

	var countForMove2 = 1;
	$("body").delegate(".move_next2","click",function(e){
	++countForMove2;
	$("#show_dashboard_title2").html(holdTITLE2[countForMove2]);
	$("#show_dashboard_des2").html(holdDES2[countForMove2]);
	$("#show_dashboard_figure2").html(holdFIGURE2[countForMove2]);

	if(countForMove2>=c12){
		countForMove2 = 0;
	}
	

	});


	$("body").delegate(".move_back2","click",function(e){
		countForMove2--;
		if(countForMove2<=0){
		 countForMove2 = 0;
	}
	$("#show_dashboard_title2").html(holdTITLE2[countForMove2]);
	$("#show_dashboard_des2").html(holdDES2[countForMove2]);
	$("#show_dashboard_figure2").html(holdFIGURE2[countForMove2]);

	});




});